package com.one;

public class MyClass {
	 void display() {
		System.out.println("Display MyClass");
	}
	//public void main(String []args) {
	public void useDisplay() {	
		display();
	}
}

