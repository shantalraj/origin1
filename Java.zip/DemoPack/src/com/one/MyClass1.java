package com.one;

public class MyClass1 {

	public void demo() {
		MyClass m = new MyClass();
		m.display();
	}

}
