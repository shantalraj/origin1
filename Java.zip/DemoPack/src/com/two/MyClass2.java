package com.two;

import com.one.MyClass;

public class MyClass2 {
	public void data() {
		MyClass m = new MyClass();
		m.display();
	}
}
