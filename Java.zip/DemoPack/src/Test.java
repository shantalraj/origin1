import com.one.MyClass;
import com.one.*;
public class Test {
	public static void main(String[] args) {
		MyClass m;
		m = new MyClass();
		m.display();
	}
}
