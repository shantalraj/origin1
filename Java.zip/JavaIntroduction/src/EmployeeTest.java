
public class EmployeeTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Employee per = new Employee();
		per.display();
		
	}

}
