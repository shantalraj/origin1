package com.pojo;

import java.util.Scanner;

public class Test {
	public static void main(String[] args) {
//		Student s = new Student();
//		
//		s.display();
//		
//		
//		Scanner sc = new Scanner(System.in);
		boolean toi;
		System.out.println(toi);
//		String str;
//		int [] arr = new int[2];
//		int roll;
//		System.out.println("Please enter the name");
//		str = sc.nextLine();
//		System.out.println("Enter marks");
//		for(int i=0; i<2;i++)
//			arr[i] = sc.nextInt();
//		System.out.println();
//		System.out.println("Enter Roll No.");
//		roll = sc.nextInt();
//		Student s2 = new Student(str,arr,roll);
//		s2.display();
//		System.out.println(s.rollno);
	}
}
