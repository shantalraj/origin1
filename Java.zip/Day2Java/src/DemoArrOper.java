import java.util.Arrays;

public class DemoArrOper {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int [] numbers = {12,34, 44,54,34,55,65,78,90,23,90};
//		Arrays.fill(numbers,0);
//		Arrays.fill(numbers, 2,5,0);
//		int [] arr_copy = Arrays.copyOf(numbers, 13);
		
		int [] arr_copy = Arrays.copyOf(numbers, 16);
		for(int num:numbers)
		{
			System.out.print(num + "\t");
		}
		System.out.println();
		for(int num:arr_copy)
		{
			System.out.print(num + "\t");
		}
		System.out.println("\n----------------------------------------------------------------------------------");
		String []names = {"ABC","XYZ","LMN"};
		String []names1 = {"ABC","XYZ","LM0"};
		boolean data=Arrays.equals(names, names1);
		if(data) {
			System.out.println("Equal");
		}
		else
			System.out.println("not equal");
		System.out.println("\n----------------------------------------------------------------------------------");
		Arrays.sort(numbers);
		for(int num:numbers)
		{
			System.out.print(num + "\t");
		}
		System.out.println();
		int found=Arrays.binarySearch(numbers, 34);
		System.out.println(found);
	}

}
