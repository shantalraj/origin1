
public class Demo1DObject {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Person [] persons;
		persons=new Person[5];
		persons[0] = new Person();
		persons[1] = new Person(34,"Bill");
		persons[2] = new Person();
		persons[3] = new Person(28, "Mike");
		persons[4] = new Person();
		for(Person x:persons)
		{
			x.display();
		}
	}

}
