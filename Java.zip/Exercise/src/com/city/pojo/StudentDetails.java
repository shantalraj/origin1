package com.city.pojo;
class student{
	private int rollno;
	private String name, insti;
}
public class StudentDetails {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
