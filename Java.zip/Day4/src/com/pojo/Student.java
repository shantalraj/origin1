package com.pojo;

import java.io.Serializable;

public class Student implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private int roll, total;
	private String name;
	public Student() {
		
	}
	public Student(int roll, int total, String name) {
		super();
		this.roll = roll;
		this.total = total;
		this.name = name;
	}
	@Override
	public String toString() {
		return "Student [roll=" + roll + ", total=" + total + ", name=" + name + "]";
	}
	public int getRoll() {
		return roll;
	}
	public void setRoll(int roll) {
		this.roll = roll;
	}
	public int getTotal() {
		return total;
	}
	public void setTotal(int total) {
		this.total = total;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	
	
	
}
