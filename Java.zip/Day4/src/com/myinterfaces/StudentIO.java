package com.myinterfaces;

import com.pojo.Student;

public interface StudentIO {
	Student[] readFromUser();
	void writeToUser(Student[] students);
}
