package com.pojo;

import java.util.Scanner;

public class TestEmpUser {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.println("Please enter the age");
		int a = sc.nextInt();
		
		System.out.println("please enter the name");
		String n = sc.next();	
		
		System.out.println("Please enter the emp ID");
		int eid = sc.nextInt();
		
		System.out.println("Please enter his/her Salary");
		double sal = sc.nextDouble();
		Employee emp = new Employee(eid,sal,a,n);
//		emp.display();
	}

}
