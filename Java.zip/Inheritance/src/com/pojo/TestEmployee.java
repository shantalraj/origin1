package com.pojo;

import java.util.Scanner;

public class TestEmployee {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Employee emp = new Employee(123,20000d,32,"Citi123");
		System.out.println(emp);				// toString() is implicitly invoked
//		emp.display();
		
	}

}
