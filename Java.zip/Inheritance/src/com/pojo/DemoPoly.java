package com.pojo;

public class DemoPoly {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Person e = new Employee();			//Superclass ref = obj of subclass
		((Employee)e).display(10);
	}

}

